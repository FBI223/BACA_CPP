

#ifndef LAB6_RANGE_H
#define LAB6_RANGE_H

template <typename T>
class Range{
 
};


#endif //LAB6_RANGE_H
